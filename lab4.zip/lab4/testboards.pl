testBoard1([ [.,.,.,.,.,.],
             [.,1,.,.,.,.],
             [.,.,2,1,.,.],
             [.,.,1,2,.,.],
             [.,.,.,.,1,.],
             [.,.,.,.,.,.] ]).

testBoard2([ [.,2,.,.,.,2],
             [.,.,1,.,1,.],
             [.,.,.,1,.,.],
             [.,.,1,1,1,.],
             [.,1,.,1,.,.],
             [.,.,.,2,.,.] ]).

testBoard3([ [.,.,.,2,.,.],
             [.,2,.,1,1,.],
             [2,1,1,1,.,.],
             [2,1,1,.,1,2],
             [.,1,.,1,.,.],
             [2,.,.,2,2,.] ]).

testBoard4([ [.,2,2,2,2,1],
             [.,1,.,1,.,.],
             [.,.,2,1,.,.],
             [.,.,1,2,.,.],
             [.,.,.,.,1,.],
             [.,.,.,.,.,.] ]).

%test validmove
%testBoard5(Board), validmove(2, Board, 1).
%testBoard5(Board), validmove(1, Board, 1).
%testBoard5(Board), validmove(2, Board, 22).
%testBoard5(Board), validmove(1, Board, 22).
%testBoard5(Board), validmove(2, Board, 31).
testBoard5([ [.,.,.,2,.,1],
             [.,2,.,1,2,.],
             [2,1,1,2,.,.],
             [2,1,2,.,1,2],
             [.,.,.,1,.,.],
             [.,.,.,2,2,.] ]).

%test nextState
% testBoard6(Board), nextState(1, 31, Board, NewBoard, NxtPlyr), showState(NewBoard).
testBoard6([ [.,.,1,.,.,1],
             [.,2,.,1,2,.],
             [.,.,2,2,.,.],
             [.,.,2,.,.,.],
             [.,2,.,.,.,.],
             [.,2,2,2,1,.] ]).

%no available moves for player 1
%print heurestic value
% testBoard7(Board), moves(1, Board, MvList1), moves(2, Board, MvList2), h(Board, Val).
testBoard7([ [.,.,.,.,.,.],
             [.,1,1,1,1,.],
             [.,1,1,1,1,.],
             [.,1,1,2,1,.],
             [.,1,1,1,1,.],
             [.,.,.,.,.,.] ]).

%check flips all directions
% testBoard8(Board), nextState(2, 22, Board, NewBoard, NxtPlyr), showState(NewBoard).
testBoard8([ [2,2,2,2,2,2],
             [2,2,2,2,2,2],
             [2,2,1,1,1,2],
             [2,2,1,.,1,2],
             [2,2,1,1,1,2],
             [2,2,2,2,2,2] ]).

%tie
testBoard9([ [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1] ]).

%winner
testBoard10([ [2,2,2,2,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1] ]).

%winner (terminal state).
testBoard11([[2,2,2,.,1,1],
             [2,2,2,1,1,1],
             [2,2,2,1,1,1],
             [2,2,2,.,1,1],
             [2,2,2,.,.,1],
             [2,2,2,.,1,.] ]).


%testBoardLAYOUT([ [1,2,3,4,5,6],
%1             [7,8,9,10,11,12],
%2             [13,14,15,16,17,18],
%3             [19,20,21,22,23,24],
%4             [25,26,27,28,29,30],
%5             [31,32,33,34,35,36] ]).
